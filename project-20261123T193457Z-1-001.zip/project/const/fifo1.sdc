###################################################################

# Created by write_sdc on Tue Oct 13 12:14:53 2026

###################################################################
set sdc_version 2.1

set_units -time ns -resistance MOhm -capacitance fF -voltage V -current uA
set_max_area 0
create_clock [get_ports wclk]  -period 10  -waveform {0 5}
set_clock_uncertainty 0.2  [get_clocks wclk]
create_clock [get_ports rclk]  -period 15  -waveform {0 7.5}
set_clock_uncertainty 0.2  [get_clocks rclk]
group_path -name REGIN  -from [list [get_ports {wdata[7]}] [get_ports {wdata[6]}] [get_ports          \
{wdata[5]}] [get_ports {wdata[4]}] [get_ports {wdata[3]}] [get_ports           \
{wdata[2]}] [get_ports {wdata[1]}] [get_ports {wdata[0]}] [get_ports winc]     \
[get_ports wrst_n] [get_ports rinc] [get_ports rrst_n]]
group_path -name REGOUT  -to [list [get_ports {rdata[7]}] [get_ports {rdata[6]}] [get_ports            \
{rdata[5]}] [get_ports {rdata[4]}] [get_ports {rdata[3]}] [get_ports           \
{rdata[2]}] [get_ports {rdata[1]}] [get_ports {rdata[0]}] [get_ports wfull]    \
[get_ports rempty]]
set_input_delay -clock wclk  2  [get_ports {wdata[7]}]
set_input_delay -clock wclk  2  [get_ports {wdata[6]}]
set_input_delay -clock wclk  2  [get_ports {wdata[5]}]
set_input_delay -clock wclk  2  [get_ports {wdata[4]}]
set_input_delay -clock wclk  2  [get_ports {wdata[3]}]
set_input_delay -clock wclk  2  [get_ports {wdata[2]}]
set_input_delay -clock wclk  2  [get_ports {wdata[1]}]
set_input_delay -clock wclk  2  [get_ports {wdata[0]}]
set_input_delay -clock wclk  2  [get_ports winc]
set_input_delay -clock wclk  2  [get_ports wrst_n]
set_input_delay -clock rclk  2  [get_ports rinc]
set_input_delay -clock rclk  2  [get_ports rrst_n]
set_output_delay -clock rclk  2  [get_ports {rdata[7]}]
set_output_delay -clock rclk  2  [get_ports {rdata[6]}]
set_output_delay -clock rclk  2  [get_ports {rdata[5]}]
set_output_delay -clock rclk  2  [get_ports {rdata[4]}]
set_output_delay -clock rclk  2  [get_ports {rdata[3]}]
set_output_delay -clock rclk  2  [get_ports {rdata[2]}]
set_output_delay -clock rclk  2  [get_ports {rdata[1]}]
set_output_delay -clock rclk  2  [get_ports {rdata[0]}]
set_output_delay -clock wclk  2  [get_ports wfull]
set_output_delay -clock rclk  2  [get_ports rempty]
set_clock_groups  -asynchronous -name wclk_1  -group [get_clocks wclk] -group  \
[get_clocks rclk]
