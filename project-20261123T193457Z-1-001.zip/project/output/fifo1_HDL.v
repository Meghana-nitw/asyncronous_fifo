/////////////////////////////////////////////////////////////
// Created by: Synopsys DC Expert(TM) in wire load mode
// Version   : W-2024.09
// Date      : Tue Oct 13 12:14:53 2026
/////////////////////////////////////////////////////////////


module sync_r2w ( wq2_rptr, rptr, wclk, wrst_n );
  output [4:0] wq2_rptr;
  input [4:0] rptr;
  input wclk, wrst_n;

  wire   [4:0] wq1_rptr;

  DFFARX1_RVT wq1_rptr_reg_4_ ( .D(rptr[4]), .CLK(wclk), .RSTB(wrst_n), .Q(
        wq1_rptr[4]) );
  DFFARX1_RVT wq2_rptr_reg_4_ ( .D(wq1_rptr[4]), .CLK(wclk), .RSTB(wrst_n), 
        .Q(wq2_rptr[4]) );
  DFFARX1_RVT wq1_rptr_reg_3_ ( .D(rptr[3]), .CLK(wclk), .RSTB(wrst_n), .Q(
        wq1_rptr[3]) );
  DFFARX1_RVT wq2_rptr_reg_3_ ( .D(wq1_rptr[3]), .CLK(wclk), .RSTB(wrst_n), 
        .Q(wq2_rptr[3]) );
  DFFARX1_RVT wq1_rptr_reg_2_ ( .D(rptr[2]), .CLK(wclk), .RSTB(wrst_n), .Q(
        wq1_rptr[2]) );
  DFFARX1_RVT wq2_rptr_reg_2_ ( .D(wq1_rptr[2]), .CLK(wclk), .RSTB(wrst_n), 
        .Q(wq2_rptr[2]) );
  DFFARX1_RVT wq1_rptr_reg_1_ ( .D(rptr[1]), .CLK(wclk), .RSTB(wrst_n), .Q(
        wq1_rptr[1]) );
  DFFARX1_RVT wq2_rptr_reg_1_ ( .D(wq1_rptr[1]), .CLK(wclk), .RSTB(wrst_n), 
        .Q(wq2_rptr[1]) );
  DFFARX1_RVT wq1_rptr_reg_0_ ( .D(rptr[0]), .CLK(wclk), .RSTB(wrst_n), .Q(
        wq1_rptr[0]) );
  DFFARX1_RVT wq2_rptr_reg_0_ ( .D(wq1_rptr[0]), .CLK(wclk), .RSTB(wrst_n), 
        .Q(wq2_rptr[0]) );
endmodule


module sync_w2r ( rq2_wptr, wptr, rclk, rrst_n );
  output [4:0] rq2_wptr;
  input [4:0] wptr;
  input rclk, rrst_n;

  wire   [4:0] rq1_wptr;

  DFFARX1_RVT rq1_wptr_reg_4_ ( .D(wptr[4]), .CLK(rclk), .RSTB(rrst_n), .Q(
        rq1_wptr[4]) );
  DFFARX1_RVT rq2_wptr_reg_4_ ( .D(rq1_wptr[4]), .CLK(rclk), .RSTB(rrst_n), 
        .Q(rq2_wptr[4]) );
  DFFARX1_RVT rq1_wptr_reg_3_ ( .D(wptr[3]), .CLK(rclk), .RSTB(rrst_n), .Q(
        rq1_wptr[3]) );
  DFFARX1_RVT rq2_wptr_reg_3_ ( .D(rq1_wptr[3]), .CLK(rclk), .RSTB(rrst_n), 
        .Q(rq2_wptr[3]) );
  DFFARX1_RVT rq1_wptr_reg_2_ ( .D(wptr[2]), .CLK(rclk), .RSTB(rrst_n), .Q(
        rq1_wptr[2]) );
  DFFARX1_RVT rq2_wptr_reg_2_ ( .D(rq1_wptr[2]), .CLK(rclk), .RSTB(rrst_n), 
        .Q(rq2_wptr[2]) );
  DFFARX1_RVT rq1_wptr_reg_1_ ( .D(wptr[1]), .CLK(rclk), .RSTB(rrst_n), .Q(
        rq1_wptr[1]) );
  DFFARX1_RVT rq2_wptr_reg_1_ ( .D(rq1_wptr[1]), .CLK(rclk), .RSTB(rrst_n), 
        .Q(rq2_wptr[1]) );
  DFFARX1_RVT rq1_wptr_reg_0_ ( .D(wptr[0]), .CLK(rclk), .RSTB(rrst_n), .Q(
        rq1_wptr[0]) );
  DFFARX1_RVT rq2_wptr_reg_0_ ( .D(rq1_wptr[0]), .CLK(rclk), .RSTB(rrst_n), 
        .Q(rq2_wptr[0]) );
endmodule


module fifomem_DATASIZE8_ADDRSIZE4 ( rdata, wdata, waddr, raddr, wclken, wfull, 
        wclk );
  output [7:0] rdata;
  input [7:0] wdata;
  input [3:0] waddr;
  input [3:0] raddr;
  input wclken, wfull, wclk;
  wire   n22, n23, n24, n25, n26, n27, n28, n29, n30, n31, n32, n33, n34, n35,
         n36, n37, n38, n39, n40, n41, n42, n43, n44, n45, n46, n47, n48, n49,
         n50, n51, n52, n53, n54, n55, n56, n57, n58, n59, n60, n61, n62, n63,
         n64, n65, n66, n67, n68, n69, n70, n71, n72, n73, n74, n75, n76, n77,
         n78, n79, n80, n81, n82, n83, n84, n85, n86, n87, n88, n89, n90, n91,
         n92, n93, n94, n95, n96, n97, n98, n99, n100, n101, n102, n103, n104,
         n105, n106, n107, n108, n109, n110, n111, n112, n113, n114, n115,
         n116, n117, n118, n119, n120, n121, n122, n123, n124, n125, n126,
         n127, n128, n129, n130, n131, n132, n133, n134, n135, n136, n137,
         n138, n139, n140, n141, n142, n143, n144, n145, n146, n147, n148,
         n149, n150, n151, n152, n153, n154, n155, n156, n157, n158, n159,
         n160, n161, n162, n163, n164, n165, n166, n167, n168, n169, n170,
         n171, n172, n173, n174, n175, n176, n1, n2, n3, n4, n5, n6, n7, n8,
         n9, n10, n11, n12, n13, n14, n15, n16, n17, n18, n19, n20, n21, n177,
         n178, n179, n180, n181, n182, n183, n184, n185, n186, n187, n188,
         n189, n190, n191, n192, n193, n194, n195, n196, n197, n198, n199,
         n200, n201, n202, n203, n204, n205, n206, n207, n208, n209, n210,
         n211, n212, n213, n214, n215, n216, n217, n218, n219, n220, n221,
         n222, n223, n224, n225, n226, n227, n228, n229, n230, n231, n232,
         n233, n234, n235, n236, n237, n238, n239, n240, n241, n242, n243,
         n244, n245, n246, n247, n248, n249, n250, n251, n252, n253, n254,
         n255, n256, n257, n258, n259, n260, n261, n262, n263, n264, n265;
  wire   [127:0] mem;

  DFFX1_RVT mem_reg_0__7_ ( .D(n176), .CLK(wclk), .Q(mem[127]) );
  DFFX1_RVT mem_reg_0__6_ ( .D(n175), .CLK(wclk), .Q(mem[126]) );
  DFFX1_RVT mem_reg_0__5_ ( .D(n174), .CLK(wclk), .Q(mem[125]) );
  DFFX1_RVT mem_reg_0__4_ ( .D(n173), .CLK(wclk), .Q(mem[124]) );
  DFFX1_RVT mem_reg_0__3_ ( .D(n172), .CLK(wclk), .Q(mem[123]) );
  DFFX1_RVT mem_reg_0__2_ ( .D(n171), .CLK(wclk), .Q(mem[122]) );
  DFFX1_RVT mem_reg_0__1_ ( .D(n170), .CLK(wclk), .Q(mem[121]) );
  DFFX1_RVT mem_reg_0__0_ ( .D(n169), .CLK(wclk), .Q(mem[120]) );
  DFFX1_RVT mem_reg_1__7_ ( .D(n168), .CLK(wclk), .Q(mem[119]) );
  DFFX1_RVT mem_reg_1__6_ ( .D(n167), .CLK(wclk), .Q(mem[118]) );
  DFFX1_RVT mem_reg_1__5_ ( .D(n166), .CLK(wclk), .Q(mem[117]) );
  DFFX1_RVT mem_reg_1__4_ ( .D(n165), .CLK(wclk), .Q(mem[116]) );
  DFFX1_RVT mem_reg_1__3_ ( .D(n164), .CLK(wclk), .Q(mem[115]) );
  DFFX1_RVT mem_reg_1__2_ ( .D(n163), .CLK(wclk), .Q(mem[114]) );
  DFFX1_RVT mem_reg_1__1_ ( .D(n162), .CLK(wclk), .Q(mem[113]) );
  DFFX1_RVT mem_reg_1__0_ ( .D(n161), .CLK(wclk), .Q(mem[112]) );
  DFFX1_RVT mem_reg_2__7_ ( .D(n160), .CLK(wclk), .Q(mem[111]) );
  DFFX1_RVT mem_reg_2__6_ ( .D(n159), .CLK(wclk), .Q(mem[110]) );
  DFFX1_RVT mem_reg_2__5_ ( .D(n158), .CLK(wclk), .Q(mem[109]) );
  DFFX1_RVT mem_reg_2__4_ ( .D(n157), .CLK(wclk), .Q(mem[108]) );
  DFFX1_RVT mem_reg_2__3_ ( .D(n156), .CLK(wclk), .Q(mem[107]) );
  DFFX1_RVT mem_reg_2__2_ ( .D(n155), .CLK(wclk), .Q(mem[106]) );
  DFFX1_RVT mem_reg_2__1_ ( .D(n154), .CLK(wclk), .Q(mem[105]) );
  DFFX1_RVT mem_reg_2__0_ ( .D(n153), .CLK(wclk), .Q(mem[104]) );
  DFFX1_RVT mem_reg_3__7_ ( .D(n152), .CLK(wclk), .Q(mem[103]) );
  DFFX1_RVT mem_reg_3__6_ ( .D(n151), .CLK(wclk), .Q(mem[102]) );
  DFFX1_RVT mem_reg_3__5_ ( .D(n150), .CLK(wclk), .Q(mem[101]) );
  DFFX1_RVT mem_reg_3__4_ ( .D(n149), .CLK(wclk), .Q(mem[100]) );
  DFFX1_RVT mem_reg_3__3_ ( .D(n148), .CLK(wclk), .Q(mem[99]) );
  DFFX1_RVT mem_reg_3__2_ ( .D(n147), .CLK(wclk), .Q(mem[98]) );
  DFFX1_RVT mem_reg_3__1_ ( .D(n146), .CLK(wclk), .Q(mem[97]) );
  DFFX1_RVT mem_reg_3__0_ ( .D(n145), .CLK(wclk), .Q(mem[96]) );
  DFFX1_RVT mem_reg_4__7_ ( .D(n144), .CLK(wclk), .Q(mem[95]) );
  DFFX1_RVT mem_reg_4__6_ ( .D(n143), .CLK(wclk), .Q(mem[94]) );
  DFFX1_RVT mem_reg_4__5_ ( .D(n142), .CLK(wclk), .Q(mem[93]) );
  DFFX1_RVT mem_reg_4__4_ ( .D(n141), .CLK(wclk), .Q(mem[92]) );
  DFFX1_RVT mem_reg_4__3_ ( .D(n140), .CLK(wclk), .Q(mem[91]) );
  DFFX1_RVT mem_reg_4__2_ ( .D(n139), .CLK(wclk), .Q(mem[90]) );
  DFFX1_RVT mem_reg_4__1_ ( .D(n138), .CLK(wclk), .Q(mem[89]) );
  DFFX1_RVT mem_reg_4__0_ ( .D(n137), .CLK(wclk), .Q(mem[88]) );
  DFFX1_RVT mem_reg_5__7_ ( .D(n136), .CLK(wclk), .Q(mem[87]) );
  DFFX1_RVT mem_reg_5__6_ ( .D(n135), .CLK(wclk), .Q(mem[86]) );
  DFFX1_RVT mem_reg_5__5_ ( .D(n134), .CLK(wclk), .Q(mem[85]) );
  DFFX1_RVT mem_reg_5__4_ ( .D(n133), .CLK(wclk), .Q(mem[84]) );
  DFFX1_RVT mem_reg_5__3_ ( .D(n132), .CLK(wclk), .Q(mem[83]) );
  DFFX1_RVT mem_reg_5__2_ ( .D(n131), .CLK(wclk), .Q(mem[82]) );
  DFFX1_RVT mem_reg_5__1_ ( .D(n130), .CLK(wclk), .Q(mem[81]) );
  DFFX1_RVT mem_reg_5__0_ ( .D(n129), .CLK(wclk), .Q(mem[80]) );
  DFFX1_RVT mem_reg_6__7_ ( .D(n128), .CLK(wclk), .Q(mem[79]) );
  DFFX1_RVT mem_reg_6__6_ ( .D(n127), .CLK(wclk), .Q(mem[78]) );
  DFFX1_RVT mem_reg_6__5_ ( .D(n126), .CLK(wclk), .Q(mem[77]) );
  DFFX1_RVT mem_reg_6__4_ ( .D(n125), .CLK(wclk), .Q(mem[76]) );
  DFFX1_RVT mem_reg_6__3_ ( .D(n124), .CLK(wclk), .Q(mem[75]) );
  DFFX1_RVT mem_reg_6__2_ ( .D(n123), .CLK(wclk), .Q(mem[74]) );
  DFFX1_RVT mem_reg_6__1_ ( .D(n122), .CLK(wclk), .Q(mem[73]) );
  DFFX1_RVT mem_reg_6__0_ ( .D(n121), .CLK(wclk), .Q(mem[72]) );
  DFFX1_RVT mem_reg_7__7_ ( .D(n120), .CLK(wclk), .Q(mem[71]) );
  DFFX1_RVT mem_reg_7__6_ ( .D(n119), .CLK(wclk), .Q(mem[70]) );
  DFFX1_RVT mem_reg_7__5_ ( .D(n118), .CLK(wclk), .Q(mem[69]) );
  DFFX1_RVT mem_reg_7__4_ ( .D(n117), .CLK(wclk), .Q(mem[68]) );
  DFFX1_RVT mem_reg_7__3_ ( .D(n116), .CLK(wclk), .Q(mem[67]) );
  DFFX1_RVT mem_reg_7__2_ ( .D(n115), .CLK(wclk), .Q(mem[66]) );
  DFFX1_RVT mem_reg_7__1_ ( .D(n114), .CLK(wclk), .Q(mem[65]) );
  DFFX1_RVT mem_reg_7__0_ ( .D(n113), .CLK(wclk), .Q(mem[64]) );
  DFFX1_RVT mem_reg_8__7_ ( .D(n112), .CLK(wclk), .Q(mem[63]) );
  DFFX1_RVT mem_reg_8__6_ ( .D(n111), .CLK(wclk), .Q(mem[62]) );
  DFFX1_RVT mem_reg_8__5_ ( .D(n110), .CLK(wclk), .Q(mem[61]) );
  DFFX1_RVT mem_reg_8__4_ ( .D(n109), .CLK(wclk), .Q(mem[60]) );
  DFFX1_RVT mem_reg_8__3_ ( .D(n108), .CLK(wclk), .Q(mem[59]) );
  DFFX1_RVT mem_reg_8__2_ ( .D(n107), .CLK(wclk), .Q(mem[58]) );
  DFFX1_RVT mem_reg_8__1_ ( .D(n106), .CLK(wclk), .Q(mem[57]) );
  DFFX1_RVT mem_reg_8__0_ ( .D(n105), .CLK(wclk), .Q(mem[56]) );
  DFFX1_RVT mem_reg_9__7_ ( .D(n104), .CLK(wclk), .Q(mem[55]) );
  DFFX1_RVT mem_reg_9__6_ ( .D(n103), .CLK(wclk), .Q(mem[54]) );
  DFFX1_RVT mem_reg_9__5_ ( .D(n102), .CLK(wclk), .Q(mem[53]) );
  DFFX1_RVT mem_reg_9__4_ ( .D(n101), .CLK(wclk), .Q(mem[52]) );
  DFFX1_RVT mem_reg_9__3_ ( .D(n100), .CLK(wclk), .Q(mem[51]) );
  DFFX1_RVT mem_reg_9__2_ ( .D(n99), .CLK(wclk), .Q(mem[50]) );
  DFFX1_RVT mem_reg_9__1_ ( .D(n98), .CLK(wclk), .Q(mem[49]) );
  DFFX1_RVT mem_reg_9__0_ ( .D(n97), .CLK(wclk), .Q(mem[48]) );
  DFFX1_RVT mem_reg_10__7_ ( .D(n96), .CLK(wclk), .Q(mem[47]) );
  DFFX1_RVT mem_reg_10__6_ ( .D(n95), .CLK(wclk), .Q(mem[46]) );
  DFFX1_RVT mem_reg_10__5_ ( .D(n94), .CLK(wclk), .Q(mem[45]) );
  DFFX1_RVT mem_reg_10__4_ ( .D(n93), .CLK(wclk), .Q(mem[44]) );
  DFFX1_RVT mem_reg_10__3_ ( .D(n92), .CLK(wclk), .Q(mem[43]) );
  DFFX1_RVT mem_reg_10__2_ ( .D(n91), .CLK(wclk), .Q(mem[42]) );
  DFFX1_RVT mem_reg_10__1_ ( .D(n90), .CLK(wclk), .Q(mem[41]) );
  DFFX1_RVT mem_reg_10__0_ ( .D(n89), .CLK(wclk), .Q(mem[40]) );
  DFFX1_RVT mem_reg_11__7_ ( .D(n88), .CLK(wclk), .Q(mem[39]) );
  DFFX1_RVT mem_reg_11__6_ ( .D(n87), .CLK(wclk), .Q(mem[38]) );
  DFFX1_RVT mem_reg_11__5_ ( .D(n86), .CLK(wclk), .Q(mem[37]) );
  DFFX1_RVT mem_reg_11__4_ ( .D(n85), .CLK(wclk), .Q(mem[36]) );
  DFFX1_RVT mem_reg_11__3_ ( .D(n84), .CLK(wclk), .Q(mem[35]) );
  DFFX1_RVT mem_reg_11__2_ ( .D(n83), .CLK(wclk), .Q(mem[34]) );
  DFFX1_RVT mem_reg_11__1_ ( .D(n82), .CLK(wclk), .Q(mem[33]) );
  DFFX1_RVT mem_reg_11__0_ ( .D(n81), .CLK(wclk), .Q(mem[32]) );
  DFFX1_RVT mem_reg_12__7_ ( .D(n80), .CLK(wclk), .Q(mem[31]) );
  DFFX1_RVT mem_reg_12__6_ ( .D(n79), .CLK(wclk), .Q(mem[30]) );
  DFFX1_RVT mem_reg_12__5_ ( .D(n78), .CLK(wclk), .Q(mem[29]) );
  DFFX1_RVT mem_reg_12__4_ ( .D(n77), .CLK(wclk), .Q(mem[28]) );
  DFFX1_RVT mem_reg_12__3_ ( .D(n76), .CLK(wclk), .Q(mem[27]) );
  DFFX1_RVT mem_reg_12__2_ ( .D(n75), .CLK(wclk), .Q(mem[26]) );
  DFFX1_RVT mem_reg_12__1_ ( .D(n74), .CLK(wclk), .Q(mem[25]) );
  DFFX1_RVT mem_reg_12__0_ ( .D(n73), .CLK(wclk), .Q(mem[24]) );
  DFFX1_RVT mem_reg_13__7_ ( .D(n72), .CLK(wclk), .Q(mem[23]) );
  DFFX1_RVT mem_reg_13__6_ ( .D(n71), .CLK(wclk), .Q(mem[22]) );
  DFFX1_RVT mem_reg_13__5_ ( .D(n70), .CLK(wclk), .Q(mem[21]) );
  DFFX1_RVT mem_reg_13__4_ ( .D(n69), .CLK(wclk), .Q(mem[20]) );
  DFFX1_RVT mem_reg_13__3_ ( .D(n68), .CLK(wclk), .Q(mem[19]) );
  DFFX1_RVT mem_reg_13__2_ ( .D(n67), .CLK(wclk), .Q(mem[18]) );
  DFFX1_RVT mem_reg_13__1_ ( .D(n66), .CLK(wclk), .Q(mem[17]) );
  DFFX1_RVT mem_reg_13__0_ ( .D(n65), .CLK(wclk), .Q(mem[16]) );
  DFFX1_RVT mem_reg_14__7_ ( .D(n64), .CLK(wclk), .Q(mem[15]) );
  DFFX1_RVT mem_reg_14__6_ ( .D(n63), .CLK(wclk), .Q(mem[14]) );
  DFFX1_RVT mem_reg_14__5_ ( .D(n62), .CLK(wclk), .Q(mem[13]) );
  DFFX1_RVT mem_reg_14__4_ ( .D(n61), .CLK(wclk), .Q(mem[12]) );
  DFFX1_RVT mem_reg_14__3_ ( .D(n60), .CLK(wclk), .Q(mem[11]) );
  DFFX1_RVT mem_reg_14__2_ ( .D(n59), .CLK(wclk), .Q(mem[10]) );
  DFFX1_RVT mem_reg_14__1_ ( .D(n58), .CLK(wclk), .Q(mem[9]) );
  DFFX1_RVT mem_reg_14__0_ ( .D(n57), .CLK(wclk), .Q(mem[8]) );
  DFFX1_RVT mem_reg_15__7_ ( .D(n56), .CLK(wclk), .Q(mem[7]) );
  DFFX1_RVT mem_reg_15__6_ ( .D(n55), .CLK(wclk), .Q(mem[6]) );
  DFFX1_RVT mem_reg_15__5_ ( .D(n54), .CLK(wclk), .Q(mem[5]) );
  DFFX1_RVT mem_reg_15__4_ ( .D(n53), .CLK(wclk), .Q(mem[4]) );
  DFFX1_RVT mem_reg_15__3_ ( .D(n52), .CLK(wclk), .Q(mem[3]) );
  DFFX1_RVT mem_reg_15__2_ ( .D(n51), .CLK(wclk), .Q(mem[2]) );
  DFFX1_RVT mem_reg_15__1_ ( .D(n50), .CLK(wclk), .Q(mem[1]) );
  DFFX1_RVT mem_reg_15__0_ ( .D(n49), .CLK(wclk), .Q(mem[0]) );
  AO22X1_RVT U23 ( .A1(wdata[0]), .A2(n260), .A3(mem[0]), .A4(n22), .Y(n49) );
  AO22X1_RVT U24 ( .A1(wdata[1]), .A2(n260), .A3(mem[1]), .A4(n22), .Y(n50) );
  AO22X1_RVT U25 ( .A1(wdata[2]), .A2(n260), .A3(mem[2]), .A4(n22), .Y(n51) );
  AO22X1_RVT U26 ( .A1(wdata[3]), .A2(n260), .A3(mem[3]), .A4(n22), .Y(n52) );
  AO22X1_RVT U27 ( .A1(wdata[4]), .A2(n260), .A3(mem[4]), .A4(n22), .Y(n53) );
  AO22X1_RVT U28 ( .A1(wdata[5]), .A2(n260), .A3(mem[5]), .A4(n22), .Y(n54) );
  AO22X1_RVT U29 ( .A1(wdata[6]), .A2(n260), .A3(mem[6]), .A4(n22), .Y(n55) );
  AO22X1_RVT U30 ( .A1(wdata[7]), .A2(n260), .A3(mem[7]), .A4(n22), .Y(n56) );
  AO22X1_RVT U32 ( .A1(n256), .A2(wdata[0]), .A3(mem[8]), .A4(n25), .Y(n57) );
  AO22X1_RVT U33 ( .A1(n256), .A2(wdata[1]), .A3(mem[9]), .A4(n25), .Y(n58) );
  AO22X1_RVT U34 ( .A1(n256), .A2(wdata[2]), .A3(mem[10]), .A4(n25), .Y(n59)
         );
  AO22X1_RVT U35 ( .A1(n256), .A2(wdata[3]), .A3(mem[11]), .A4(n25), .Y(n60)
         );
  AO22X1_RVT U36 ( .A1(n256), .A2(wdata[4]), .A3(mem[12]), .A4(n25), .Y(n61)
         );
  AO22X1_RVT U37 ( .A1(n256), .A2(wdata[5]), .A3(mem[13]), .A4(n25), .Y(n62)
         );
  AO22X1_RVT U38 ( .A1(n256), .A2(wdata[6]), .A3(mem[14]), .A4(n25), .Y(n63)
         );
  AO22X1_RVT U39 ( .A1(n256), .A2(wdata[7]), .A3(mem[15]), .A4(n25), .Y(n64)
         );
  AO22X1_RVT U41 ( .A1(n259), .A2(wdata[0]), .A3(mem[16]), .A4(n27), .Y(n65)
         );
  AO22X1_RVT U42 ( .A1(n259), .A2(wdata[1]), .A3(mem[17]), .A4(n27), .Y(n66)
         );
  AO22X1_RVT U43 ( .A1(n259), .A2(wdata[2]), .A3(mem[18]), .A4(n27), .Y(n67)
         );
  AO22X1_RVT U44 ( .A1(n259), .A2(wdata[3]), .A3(mem[19]), .A4(n27), .Y(n68)
         );
  AO22X1_RVT U45 ( .A1(n259), .A2(wdata[4]), .A3(mem[20]), .A4(n27), .Y(n69)
         );
  AO22X1_RVT U46 ( .A1(n259), .A2(wdata[5]), .A3(mem[21]), .A4(n27), .Y(n70)
         );
  AO22X1_RVT U47 ( .A1(n259), .A2(wdata[6]), .A3(mem[22]), .A4(n27), .Y(n71)
         );
  AO22X1_RVT U48 ( .A1(n259), .A2(wdata[7]), .A3(mem[23]), .A4(n27), .Y(n72)
         );
  AO22X1_RVT U50 ( .A1(n255), .A2(wdata[0]), .A3(mem[24]), .A4(n29), .Y(n73)
         );
  AO22X1_RVT U51 ( .A1(n255), .A2(wdata[1]), .A3(mem[25]), .A4(n29), .Y(n74)
         );
  AO22X1_RVT U52 ( .A1(n255), .A2(wdata[2]), .A3(mem[26]), .A4(n29), .Y(n75)
         );
  AO22X1_RVT U53 ( .A1(n255), .A2(wdata[3]), .A3(mem[27]), .A4(n29), .Y(n76)
         );
  AO22X1_RVT U54 ( .A1(n255), .A2(wdata[4]), .A3(mem[28]), .A4(n29), .Y(n77)
         );
  AO22X1_RVT U55 ( .A1(n255), .A2(wdata[5]), .A3(mem[29]), .A4(n29), .Y(n78)
         );
  AO22X1_RVT U56 ( .A1(n255), .A2(wdata[6]), .A3(mem[30]), .A4(n29), .Y(n79)
         );
  AO22X1_RVT U57 ( .A1(n255), .A2(wdata[7]), .A3(mem[31]), .A4(n29), .Y(n80)
         );
  AO22X1_RVT U59 ( .A1(n258), .A2(wdata[0]), .A3(mem[32]), .A4(n30), .Y(n81)
         );
  AO22X1_RVT U60 ( .A1(n258), .A2(wdata[1]), .A3(mem[33]), .A4(n30), .Y(n82)
         );
  AO22X1_RVT U61 ( .A1(n258), .A2(wdata[2]), .A3(mem[34]), .A4(n30), .Y(n83)
         );
  AO22X1_RVT U62 ( .A1(n258), .A2(wdata[3]), .A3(mem[35]), .A4(n30), .Y(n84)
         );
  AO22X1_RVT U63 ( .A1(n258), .A2(wdata[4]), .A3(mem[36]), .A4(n30), .Y(n85)
         );
  AO22X1_RVT U64 ( .A1(n258), .A2(wdata[5]), .A3(mem[37]), .A4(n30), .Y(n86)
         );
  AO22X1_RVT U65 ( .A1(n258), .A2(wdata[6]), .A3(mem[38]), .A4(n30), .Y(n87)
         );
  AO22X1_RVT U66 ( .A1(n258), .A2(wdata[7]), .A3(mem[39]), .A4(n30), .Y(n88)
         );
  AO22X1_RVT U68 ( .A1(n254), .A2(wdata[0]), .A3(mem[40]), .A4(n32), .Y(n89)
         );
  AO22X1_RVT U69 ( .A1(n254), .A2(wdata[1]), .A3(mem[41]), .A4(n32), .Y(n90)
         );
  AO22X1_RVT U70 ( .A1(n254), .A2(wdata[2]), .A3(mem[42]), .A4(n32), .Y(n91)
         );
  AO22X1_RVT U71 ( .A1(n254), .A2(wdata[3]), .A3(mem[43]), .A4(n32), .Y(n92)
         );
  AO22X1_RVT U72 ( .A1(n254), .A2(wdata[4]), .A3(mem[44]), .A4(n32), .Y(n93)
         );
  AO22X1_RVT U73 ( .A1(n254), .A2(wdata[5]), .A3(mem[45]), .A4(n32), .Y(n94)
         );
  AO22X1_RVT U74 ( .A1(n254), .A2(wdata[6]), .A3(mem[46]), .A4(n32), .Y(n95)
         );
  AO22X1_RVT U75 ( .A1(n254), .A2(wdata[7]), .A3(mem[47]), .A4(n32), .Y(n96)
         );
  AO22X1_RVT U77 ( .A1(n257), .A2(wdata[0]), .A3(mem[48]), .A4(n33), .Y(n97)
         );
  AO22X1_RVT U78 ( .A1(n257), .A2(wdata[1]), .A3(mem[49]), .A4(n33), .Y(n98)
         );
  AO22X1_RVT U79 ( .A1(n257), .A2(wdata[2]), .A3(mem[50]), .A4(n33), .Y(n99)
         );
  AO22X1_RVT U80 ( .A1(n257), .A2(wdata[3]), .A3(mem[51]), .A4(n33), .Y(n100)
         );
  AO22X1_RVT U81 ( .A1(n257), .A2(wdata[4]), .A3(mem[52]), .A4(n33), .Y(n101)
         );
  AO22X1_RVT U82 ( .A1(n257), .A2(wdata[5]), .A3(mem[53]), .A4(n33), .Y(n102)
         );
  AO22X1_RVT U83 ( .A1(n257), .A2(wdata[6]), .A3(mem[54]), .A4(n33), .Y(n103)
         );
  AO22X1_RVT U84 ( .A1(n257), .A2(wdata[7]), .A3(mem[55]), .A4(n33), .Y(n104)
         );
  AND2X1_RVT U86 ( .A1(waddr[0]), .A2(n35), .Y(n24) );
  AO22X1_RVT U87 ( .A1(n253), .A2(wdata[0]), .A3(mem[56]), .A4(n36), .Y(n105)
         );
  AO22X1_RVT U88 ( .A1(n253), .A2(wdata[1]), .A3(mem[57]), .A4(n36), .Y(n106)
         );
  AO22X1_RVT U89 ( .A1(n253), .A2(wdata[2]), .A3(mem[58]), .A4(n36), .Y(n107)
         );
  AO22X1_RVT U90 ( .A1(n253), .A2(wdata[3]), .A3(mem[59]), .A4(n36), .Y(n108)
         );
  AO22X1_RVT U91 ( .A1(n253), .A2(wdata[4]), .A3(mem[60]), .A4(n36), .Y(n109)
         );
  AO22X1_RVT U92 ( .A1(n253), .A2(wdata[5]), .A3(mem[61]), .A4(n36), .Y(n110)
         );
  AO22X1_RVT U93 ( .A1(n253), .A2(wdata[6]), .A3(mem[62]), .A4(n36), .Y(n111)
         );
  AO22X1_RVT U94 ( .A1(n253), .A2(wdata[7]), .A3(mem[63]), .A4(n36), .Y(n112)
         );
  AND2X1_RVT U96 ( .A1(n35), .A2(n262), .Y(n26) );
  AND2X1_RVT U97 ( .A1(waddr[3]), .A2(n37), .Y(n35) );
  AO22X1_RVT U98 ( .A1(n252), .A2(wdata[0]), .A3(mem[64]), .A4(n38), .Y(n113)
         );
  AO22X1_RVT U99 ( .A1(n252), .A2(wdata[1]), .A3(mem[65]), .A4(n38), .Y(n114)
         );
  AO22X1_RVT U100 ( .A1(n252), .A2(wdata[2]), .A3(mem[66]), .A4(n38), .Y(n115)
         );
  AO22X1_RVT U101 ( .A1(n252), .A2(wdata[3]), .A3(mem[67]), .A4(n38), .Y(n116)
         );
  AO22X1_RVT U102 ( .A1(n252), .A2(wdata[4]), .A3(mem[68]), .A4(n38), .Y(n117)
         );
  AO22X1_RVT U103 ( .A1(n252), .A2(wdata[5]), .A3(mem[69]), .A4(n38), .Y(n118)
         );
  AO22X1_RVT U104 ( .A1(n252), .A2(wdata[6]), .A3(mem[70]), .A4(n38), .Y(n119)
         );
  AO22X1_RVT U105 ( .A1(n252), .A2(wdata[7]), .A3(mem[71]), .A4(n38), .Y(n120)
         );
  AO22X1_RVT U107 ( .A1(n248), .A2(wdata[0]), .A3(mem[72]), .A4(n40), .Y(n121)
         );
  AO22X1_RVT U108 ( .A1(n248), .A2(wdata[1]), .A3(mem[73]), .A4(n40), .Y(n122)
         );
  AO22X1_RVT U109 ( .A1(n248), .A2(wdata[2]), .A3(mem[74]), .A4(n40), .Y(n123)
         );
  AO22X1_RVT U110 ( .A1(n248), .A2(wdata[3]), .A3(mem[75]), .A4(n40), .Y(n124)
         );
  AO22X1_RVT U111 ( .A1(n248), .A2(wdata[4]), .A3(mem[76]), .A4(n40), .Y(n125)
         );
  AO22X1_RVT U112 ( .A1(n248), .A2(wdata[5]), .A3(mem[77]), .A4(n40), .Y(n126)
         );
  AO22X1_RVT U113 ( .A1(n248), .A2(wdata[6]), .A3(mem[78]), .A4(n40), .Y(n127)
         );
  AO22X1_RVT U114 ( .A1(n248), .A2(wdata[7]), .A3(mem[79]), .A4(n40), .Y(n128)
         );
  AND2X1_RVT U116 ( .A1(waddr[2]), .A2(waddr[1]), .Y(n23) );
  AO22X1_RVT U117 ( .A1(n251), .A2(wdata[0]), .A3(mem[80]), .A4(n42), .Y(n129)
         );
  AO22X1_RVT U118 ( .A1(n251), .A2(wdata[1]), .A3(mem[81]), .A4(n42), .Y(n130)
         );
  AO22X1_RVT U119 ( .A1(n251), .A2(wdata[2]), .A3(mem[82]), .A4(n42), .Y(n131)
         );
  AO22X1_RVT U120 ( .A1(n251), .A2(wdata[3]), .A3(mem[83]), .A4(n42), .Y(n132)
         );
  AO22X1_RVT U121 ( .A1(n251), .A2(wdata[4]), .A3(mem[84]), .A4(n42), .Y(n133)
         );
  AO22X1_RVT U122 ( .A1(n251), .A2(wdata[5]), .A3(mem[85]), .A4(n42), .Y(n134)
         );
  AO22X1_RVT U123 ( .A1(n251), .A2(wdata[6]), .A3(mem[86]), .A4(n42), .Y(n135)
         );
  AO22X1_RVT U124 ( .A1(n251), .A2(wdata[7]), .A3(mem[87]), .A4(n42), .Y(n136)
         );
  AO22X1_RVT U126 ( .A1(n247), .A2(wdata[0]), .A3(mem[88]), .A4(n43), .Y(n137)
         );
  AO22X1_RVT U127 ( .A1(n247), .A2(wdata[1]), .A3(mem[89]), .A4(n43), .Y(n138)
         );
  AO22X1_RVT U128 ( .A1(n247), .A2(wdata[2]), .A3(mem[90]), .A4(n43), .Y(n139)
         );
  AO22X1_RVT U129 ( .A1(n247), .A2(wdata[3]), .A3(mem[91]), .A4(n43), .Y(n140)
         );
  AO22X1_RVT U130 ( .A1(n247), .A2(wdata[4]), .A3(mem[92]), .A4(n43), .Y(n141)
         );
  AO22X1_RVT U131 ( .A1(n247), .A2(wdata[5]), .A3(mem[93]), .A4(n43), .Y(n142)
         );
  AO22X1_RVT U132 ( .A1(n247), .A2(wdata[6]), .A3(mem[94]), .A4(n43), .Y(n143)
         );
  AO22X1_RVT U133 ( .A1(n247), .A2(wdata[7]), .A3(mem[95]), .A4(n43), .Y(n144)
         );
  AND2X1_RVT U135 ( .A1(waddr[2]), .A2(n263), .Y(n28) );
  AO22X1_RVT U136 ( .A1(n250), .A2(wdata[0]), .A3(mem[96]), .A4(n44), .Y(n145)
         );
  AO22X1_RVT U137 ( .A1(n250), .A2(wdata[1]), .A3(mem[97]), .A4(n44), .Y(n146)
         );
  AO22X1_RVT U138 ( .A1(n250), .A2(wdata[2]), .A3(mem[98]), .A4(n44), .Y(n147)
         );
  AO22X1_RVT U139 ( .A1(n250), .A2(wdata[3]), .A3(mem[99]), .A4(n44), .Y(n148)
         );
  AO22X1_RVT U140 ( .A1(n250), .A2(wdata[4]), .A3(mem[100]), .A4(n44), .Y(n149) );
  AO22X1_RVT U141 ( .A1(n250), .A2(wdata[5]), .A3(mem[101]), .A4(n44), .Y(n150) );
  AO22X1_RVT U142 ( .A1(n250), .A2(wdata[6]), .A3(mem[102]), .A4(n44), .Y(n151) );
  AO22X1_RVT U143 ( .A1(n250), .A2(wdata[7]), .A3(mem[103]), .A4(n44), .Y(n152) );
  AO22X1_RVT U145 ( .A1(n246), .A2(wdata[0]), .A3(mem[104]), .A4(n45), .Y(n153) );
  AO22X1_RVT U146 ( .A1(n246), .A2(wdata[1]), .A3(mem[105]), .A4(n45), .Y(n154) );
  AO22X1_RVT U147 ( .A1(n246), .A2(wdata[2]), .A3(mem[106]), .A4(n45), .Y(n155) );
  AO22X1_RVT U148 ( .A1(n246), .A2(wdata[3]), .A3(mem[107]), .A4(n45), .Y(n156) );
  AO22X1_RVT U149 ( .A1(n246), .A2(wdata[4]), .A3(mem[108]), .A4(n45), .Y(n157) );
  AO22X1_RVT U150 ( .A1(n246), .A2(wdata[5]), .A3(mem[109]), .A4(n45), .Y(n158) );
  AO22X1_RVT U151 ( .A1(n246), .A2(wdata[6]), .A3(mem[110]), .A4(n45), .Y(n159) );
  AO22X1_RVT U152 ( .A1(n246), .A2(wdata[7]), .A3(mem[111]), .A4(n45), .Y(n160) );
  AND2X1_RVT U154 ( .A1(waddr[1]), .A2(n264), .Y(n31) );
  AO22X1_RVT U155 ( .A1(n249), .A2(wdata[0]), .A3(mem[112]), .A4(n46), .Y(n161) );
  AO22X1_RVT U156 ( .A1(n249), .A2(wdata[1]), .A3(mem[113]), .A4(n46), .Y(n162) );
  AO22X1_RVT U157 ( .A1(n249), .A2(wdata[2]), .A3(mem[114]), .A4(n46), .Y(n163) );
  AO22X1_RVT U158 ( .A1(n249), .A2(wdata[3]), .A3(mem[115]), .A4(n46), .Y(n164) );
  AO22X1_RVT U159 ( .A1(n249), .A2(wdata[4]), .A3(mem[116]), .A4(n46), .Y(n165) );
  AO22X1_RVT U160 ( .A1(n249), .A2(wdata[5]), .A3(mem[117]), .A4(n46), .Y(n166) );
  AO22X1_RVT U161 ( .A1(n249), .A2(wdata[6]), .A3(mem[118]), .A4(n46), .Y(n167) );
  AO22X1_RVT U162 ( .A1(n249), .A2(wdata[7]), .A3(mem[119]), .A4(n46), .Y(n168) );
  AND2X1_RVT U164 ( .A1(n47), .A2(waddr[0]), .Y(n39) );
  AO22X1_RVT U165 ( .A1(n245), .A2(wdata[0]), .A3(mem[120]), .A4(n48), .Y(n169) );
  AO22X1_RVT U166 ( .A1(n245), .A2(wdata[1]), .A3(mem[121]), .A4(n48), .Y(n170) );
  AO22X1_RVT U167 ( .A1(n245), .A2(wdata[2]), .A3(mem[122]), .A4(n48), .Y(n171) );
  AO22X1_RVT U168 ( .A1(n245), .A2(wdata[3]), .A3(mem[123]), .A4(n48), .Y(n172) );
  AO22X1_RVT U169 ( .A1(n245), .A2(wdata[4]), .A3(mem[124]), .A4(n48), .Y(n173) );
  AO22X1_RVT U170 ( .A1(n245), .A2(wdata[5]), .A3(mem[125]), .A4(n48), .Y(n174) );
  AO22X1_RVT U171 ( .A1(n245), .A2(wdata[6]), .A3(mem[126]), .A4(n48), .Y(n175) );
  AO22X1_RVT U172 ( .A1(n245), .A2(wdata[7]), .A3(mem[127]), .A4(n48), .Y(n176) );
  AND2X1_RVT U174 ( .A1(n263), .A2(n264), .Y(n34) );
  AND2X1_RVT U175 ( .A1(n47), .A2(n262), .Y(n41) );
  AND2X1_RVT U176 ( .A1(n37), .A2(n265), .Y(n47) );
  AND2X1_RVT U177 ( .A1(wclken), .A2(n261), .Y(n37) );
  INVX1_RVT U2 ( .A(n36), .Y(n253) );
  INVX1_RVT U3 ( .A(n48), .Y(n245) );
  INVX1_RVT U4 ( .A(n22), .Y(n260) );
  INVX1_RVT U5 ( .A(n27), .Y(n259) );
  INVX1_RVT U6 ( .A(n30), .Y(n258) );
  INVX1_RVT U7 ( .A(n33), .Y(n257) );
  NAND2X0_RVT U8 ( .A1(n34), .A2(n26), .Y(n36) );
  INVX1_RVT U9 ( .A(n29), .Y(n255) );
  INVX1_RVT U10 ( .A(n32), .Y(n254) );
  INVX1_RVT U11 ( .A(n25), .Y(n256) );
  INVX1_RVT U12 ( .A(n38), .Y(n252) );
  INVX1_RVT U13 ( .A(n42), .Y(n251) );
  INVX1_RVT U14 ( .A(n44), .Y(n250) );
  INVX1_RVT U15 ( .A(n46), .Y(n249) );
  NAND2X0_RVT U16 ( .A1(n41), .A2(n34), .Y(n48) );
  INVX1_RVT U17 ( .A(n40), .Y(n248) );
  INVX1_RVT U18 ( .A(n43), .Y(n247) );
  INVX1_RVT U19 ( .A(n45), .Y(n246) );
  NAND2X0_RVT U20 ( .A1(n23), .A2(n24), .Y(n22) );
  NAND2X0_RVT U21 ( .A1(n28), .A2(n24), .Y(n27) );
  NAND2X0_RVT U22 ( .A1(n31), .A2(n24), .Y(n30) );
  NAND2X0_RVT U31 ( .A1(n34), .A2(n24), .Y(n33) );
  NAND2X0_RVT U40 ( .A1(n28), .A2(n26), .Y(n29) );
  NAND2X0_RVT U49 ( .A1(n31), .A2(n26), .Y(n32) );
  NAND2X0_RVT U58 ( .A1(n26), .A2(n23), .Y(n25) );
  NAND2X0_RVT U67 ( .A1(n39), .A2(n23), .Y(n38) );
  NAND2X0_RVT U76 ( .A1(n39), .A2(n28), .Y(n42) );
  NAND2X0_RVT U85 ( .A1(n39), .A2(n31), .Y(n44) );
  NAND2X0_RVT U95 ( .A1(n39), .A2(n34), .Y(n46) );
  NAND2X0_RVT U106 ( .A1(n41), .A2(n23), .Y(n40) );
  NAND2X0_RVT U115 ( .A1(n41), .A2(n28), .Y(n43) );
  NAND2X0_RVT U125 ( .A1(n41), .A2(n31), .Y(n45) );
  NBUFFX2_RVT U134 ( .A(n222), .Y(n241) );
  NBUFFX2_RVT U144 ( .A(n222), .Y(n240) );
  NBUFFX2_RVT U153 ( .A(n226), .Y(n244) );
  INVX1_RVT U163 ( .A(wfull), .Y(n261) );
  INVX1_RVT U173 ( .A(waddr[3]), .Y(n265) );
  INVX1_RVT U178 ( .A(waddr[2]), .Y(n264) );
  INVX1_RVT U179 ( .A(waddr[1]), .Y(n263) );
  INVX1_RVT U180 ( .A(waddr[0]), .Y(n262) );
  NBUFFX2_RVT U181 ( .A(n223), .Y(n242) );
  INVX1_RVT U182 ( .A(raddr[0]), .Y(n239) );
  INVX1_RVT U183 ( .A(raddr[1]), .Y(n238) );
  NBUFFX2_RVT U184 ( .A(n225), .Y(n243) );
  INVX1_RVT U185 ( .A(raddr[3]), .Y(n236) );
  INVX1_RVT U186 ( .A(raddr[2]), .Y(n237) );
  AND2X1_RVT U187 ( .A1(n239), .A2(n238), .Y(n226) );
  AND2X1_RVT U188 ( .A1(raddr[0]), .A2(n238), .Y(n225) );
  AND2X1_RVT U189 ( .A1(raddr[1]), .A2(raddr[0]), .Y(n223) );
  AND2X1_RVT U190 ( .A1(raddr[1]), .A2(n239), .Y(n222) );
  AO22X1_RVT U191 ( .A1(mem[32]), .A2(n223), .A3(mem[40]), .A4(n241), .Y(n1)
         );
  AO221X1_RVT U192 ( .A1(mem[56]), .A2(n226), .A3(mem[48]), .A4(n225), .A5(n1), 
        .Y(n9) );
  AND2X1_RVT U193 ( .A1(raddr[3]), .A2(n237), .Y(n228) );
  AO22X1_RVT U194 ( .A1(mem[0]), .A2(n223), .A3(mem[8]), .A4(n241), .Y(n2) );
  AO221X1_RVT U195 ( .A1(mem[24]), .A2(n244), .A3(mem[16]), .A4(n243), .A5(n2), 
        .Y(n8) );
  AND2X1_RVT U196 ( .A1(raddr[3]), .A2(raddr[2]), .Y(n230) );
  AO22X1_RVT U197 ( .A1(mem[64]), .A2(n223), .A3(mem[72]), .A4(n241), .Y(n3)
         );
  AO221X1_RVT U198 ( .A1(mem[88]), .A2(n226), .A3(mem[80]), .A4(n225), .A5(n3), 
        .Y(n6) );
  AND2X1_RVT U199 ( .A1(raddr[2]), .A2(n236), .Y(n233) );
  AO22X1_RVT U200 ( .A1(mem[96]), .A2(n223), .A3(mem[104]), .A4(n241), .Y(n4)
         );
  AO221X1_RVT U201 ( .A1(mem[120]), .A2(n226), .A3(mem[112]), .A4(n225), .A5(
        n4), .Y(n5) );
  AND2X1_RVT U202 ( .A1(n237), .A2(n236), .Y(n235) );
  AO22X1_RVT U203 ( .A1(n6), .A2(n233), .A3(n5), .A4(n235), .Y(n7) );
  AO221X1_RVT U204 ( .A1(n9), .A2(n228), .A3(n8), .A4(n230), .A5(n7), .Y(
        rdata[0]) );
  AO22X1_RVT U205 ( .A1(mem[33]), .A2(n223), .A3(mem[41]), .A4(n241), .Y(n10)
         );
  AO221X1_RVT U206 ( .A1(mem[57]), .A2(n226), .A3(mem[49]), .A4(n225), .A5(n10), .Y(n18) );
  AO22X1_RVT U207 ( .A1(mem[1]), .A2(n223), .A3(mem[9]), .A4(n241), .Y(n11) );
  AO221X1_RVT U208 ( .A1(mem[25]), .A2(n226), .A3(mem[17]), .A4(n225), .A5(n11), .Y(n17) );
  AO22X1_RVT U209 ( .A1(mem[65]), .A2(n242), .A3(mem[73]), .A4(n241), .Y(n12)
         );
  AO221X1_RVT U210 ( .A1(mem[89]), .A2(n244), .A3(mem[81]), .A4(n243), .A5(n12), .Y(n15) );
  AO22X1_RVT U211 ( .A1(mem[97]), .A2(n223), .A3(mem[105]), .A4(n241), .Y(n13)
         );
  AO221X1_RVT U212 ( .A1(mem[121]), .A2(n226), .A3(mem[113]), .A4(n225), .A5(
        n13), .Y(n14) );
  AO22X1_RVT U213 ( .A1(n15), .A2(n233), .A3(n14), .A4(n235), .Y(n16) );
  AO221X1_RVT U214 ( .A1(n18), .A2(n228), .A3(n17), .A4(n230), .A5(n16), .Y(
        rdata[1]) );
  AO22X1_RVT U215 ( .A1(mem[34]), .A2(n223), .A3(mem[42]), .A4(n241), .Y(n19)
         );
  AO221X1_RVT U216 ( .A1(mem[58]), .A2(n226), .A3(mem[50]), .A4(n225), .A5(n19), .Y(n182) );
  AO22X1_RVT U217 ( .A1(mem[2]), .A2(n223), .A3(mem[10]), .A4(n241), .Y(n20)
         );
  AO221X1_RVT U218 ( .A1(mem[26]), .A2(n226), .A3(mem[18]), .A4(n225), .A5(n20), .Y(n181) );
  AO22X1_RVT U219 ( .A1(mem[66]), .A2(n242), .A3(mem[74]), .A4(n241), .Y(n21)
         );
  AO221X1_RVT U220 ( .A1(mem[90]), .A2(n244), .A3(mem[82]), .A4(n243), .A5(n21), .Y(n179) );
  AO22X1_RVT U221 ( .A1(mem[98]), .A2(n223), .A3(mem[106]), .A4(n241), .Y(n177) );
  AO221X1_RVT U222 ( .A1(mem[122]), .A2(n226), .A3(mem[114]), .A4(n225), .A5(
        n177), .Y(n178) );
  AO22X1_RVT U223 ( .A1(n179), .A2(n233), .A3(n178), .A4(n235), .Y(n180) );
  AO221X1_RVT U224 ( .A1(n182), .A2(n228), .A3(n181), .A4(n230), .A5(n180), 
        .Y(rdata[2]) );
  AO22X1_RVT U225 ( .A1(mem[35]), .A2(n223), .A3(mem[43]), .A4(n240), .Y(n183)
         );
  AO221X1_RVT U226 ( .A1(mem[59]), .A2(n226), .A3(mem[51]), .A4(n225), .A5(
        n183), .Y(n191) );
  AO22X1_RVT U227 ( .A1(mem[3]), .A2(n223), .A3(mem[11]), .A4(n240), .Y(n184)
         );
  AO221X1_RVT U228 ( .A1(mem[27]), .A2(n226), .A3(mem[19]), .A4(n225), .A5(
        n184), .Y(n190) );
  AO22X1_RVT U229 ( .A1(mem[67]), .A2(n242), .A3(mem[75]), .A4(n240), .Y(n185)
         );
  AO221X1_RVT U230 ( .A1(mem[91]), .A2(n244), .A3(mem[83]), .A4(n243), .A5(
        n185), .Y(n188) );
  AO22X1_RVT U231 ( .A1(mem[99]), .A2(n242), .A3(mem[107]), .A4(n240), .Y(n186) );
  AO221X1_RVT U232 ( .A1(mem[123]), .A2(n244), .A3(mem[115]), .A4(n243), .A5(
        n186), .Y(n187) );
  AO22X1_RVT U233 ( .A1(n188), .A2(n233), .A3(n187), .A4(n235), .Y(n189) );
  AO221X1_RVT U234 ( .A1(n191), .A2(n228), .A3(n190), .A4(n230), .A5(n189), 
        .Y(rdata[3]) );
  AO22X1_RVT U235 ( .A1(mem[36]), .A2(n223), .A3(mem[44]), .A4(n240), .Y(n192)
         );
  AO221X1_RVT U236 ( .A1(mem[60]), .A2(n226), .A3(mem[52]), .A4(n225), .A5(
        n192), .Y(n200) );
  AO22X1_RVT U237 ( .A1(mem[4]), .A2(n223), .A3(mem[12]), .A4(n240), .Y(n193)
         );
  AO221X1_RVT U238 ( .A1(mem[28]), .A2(n226), .A3(mem[20]), .A4(n225), .A5(
        n193), .Y(n199) );
  AO22X1_RVT U239 ( .A1(mem[68]), .A2(n242), .A3(mem[76]), .A4(n240), .Y(n194)
         );
  AO221X1_RVT U240 ( .A1(mem[92]), .A2(n244), .A3(mem[84]), .A4(n243), .A5(
        n194), .Y(n197) );
  AO22X1_RVT U241 ( .A1(mem[100]), .A2(n223), .A3(mem[108]), .A4(n240), .Y(
        n195) );
  AO221X1_RVT U242 ( .A1(mem[124]), .A2(n226), .A3(mem[116]), .A4(n225), .A5(
        n195), .Y(n196) );
  AO22X1_RVT U243 ( .A1(n197), .A2(n233), .A3(n196), .A4(n235), .Y(n198) );
  AO221X1_RVT U244 ( .A1(n200), .A2(n228), .A3(n199), .A4(n230), .A5(n198), 
        .Y(rdata[4]) );
  AO22X1_RVT U245 ( .A1(mem[37]), .A2(n242), .A3(mem[45]), .A4(n240), .Y(n201)
         );
  AO221X1_RVT U246 ( .A1(mem[61]), .A2(n244), .A3(mem[53]), .A4(n243), .A5(
        n201), .Y(n209) );
  AO22X1_RVT U247 ( .A1(mem[5]), .A2(n223), .A3(mem[13]), .A4(n240), .Y(n202)
         );
  AO221X1_RVT U248 ( .A1(mem[29]), .A2(n226), .A3(mem[21]), .A4(n225), .A5(
        n202), .Y(n208) );
  AO22X1_RVT U249 ( .A1(mem[69]), .A2(n242), .A3(mem[77]), .A4(n240), .Y(n203)
         );
  AO221X1_RVT U250 ( .A1(mem[93]), .A2(n244), .A3(mem[85]), .A4(n243), .A5(
        n203), .Y(n206) );
  AO22X1_RVT U251 ( .A1(mem[101]), .A2(n242), .A3(mem[109]), .A4(n240), .Y(
        n204) );
  AO221X1_RVT U252 ( .A1(mem[125]), .A2(n244), .A3(mem[117]), .A4(n243), .A5(
        n204), .Y(n205) );
  AO22X1_RVT U253 ( .A1(n206), .A2(n233), .A3(n205), .A4(n235), .Y(n207) );
  AO221X1_RVT U254 ( .A1(n209), .A2(n228), .A3(n208), .A4(n230), .A5(n207), 
        .Y(rdata[5]) );
  AO22X1_RVT U255 ( .A1(mem[38]), .A2(n242), .A3(mem[46]), .A4(n222), .Y(n210)
         );
  AO221X1_RVT U256 ( .A1(mem[62]), .A2(n244), .A3(mem[54]), .A4(n243), .A5(
        n210), .Y(n218) );
  AO22X1_RVT U257 ( .A1(mem[6]), .A2(n242), .A3(mem[14]), .A4(n222), .Y(n211)
         );
  AO221X1_RVT U258 ( .A1(mem[30]), .A2(n244), .A3(mem[22]), .A4(n243), .A5(
        n211), .Y(n217) );
  AO22X1_RVT U259 ( .A1(mem[70]), .A2(n242), .A3(mem[78]), .A4(n222), .Y(n212)
         );
  AO221X1_RVT U260 ( .A1(mem[94]), .A2(n244), .A3(mem[86]), .A4(n243), .A5(
        n212), .Y(n215) );
  AO22X1_RVT U261 ( .A1(mem[102]), .A2(n242), .A3(mem[110]), .A4(n222), .Y(
        n213) );
  AO221X1_RVT U262 ( .A1(mem[126]), .A2(n244), .A3(mem[118]), .A4(n243), .A5(
        n213), .Y(n214) );
  AO22X1_RVT U263 ( .A1(n215), .A2(n233), .A3(n214), .A4(n235), .Y(n216) );
  AO221X1_RVT U264 ( .A1(n218), .A2(n228), .A3(n217), .A4(n230), .A5(n216), 
        .Y(rdata[6]) );
  AO22X1_RVT U265 ( .A1(mem[103]), .A2(n242), .A3(mem[111]), .A4(n222), .Y(
        n219) );
  AO221X1_RVT U266 ( .A1(mem[127]), .A2(n244), .A3(mem[119]), .A4(n243), .A5(
        n219), .Y(n234) );
  AO22X1_RVT U267 ( .A1(mem[71]), .A2(n242), .A3(mem[79]), .A4(n222), .Y(n220)
         );
  AO221X1_RVT U268 ( .A1(mem[95]), .A2(n244), .A3(mem[87]), .A4(n243), .A5(
        n220), .Y(n232) );
  AO22X1_RVT U269 ( .A1(mem[7]), .A2(n242), .A3(mem[15]), .A4(n222), .Y(n221)
         );
  AO221X1_RVT U270 ( .A1(mem[31]), .A2(n244), .A3(mem[23]), .A4(n243), .A5(
        n221), .Y(n229) );
  AO22X1_RVT U271 ( .A1(mem[39]), .A2(n242), .A3(mem[47]), .A4(n222), .Y(n224)
         );
  AO221X1_RVT U272 ( .A1(mem[63]), .A2(n244), .A3(mem[55]), .A4(n243), .A5(
        n224), .Y(n227) );
  AO22X1_RVT U273 ( .A1(n230), .A2(n229), .A3(n228), .A4(n227), .Y(n231) );
  AO221X1_RVT U274 ( .A1(n235), .A2(n234), .A3(n233), .A4(n232), .A5(n231), 
        .Y(rdata[7]) );
endmodule


module rptr_empty_ADDRSIZE4 ( rempty, raddr, rptr, rq2_wptr, rinc, rclk, 
        rrst_n );
  output [3:0] raddr;
  output [4:0] rptr;
  input [4:0] rq2_wptr;
  input rinc, rclk, rrst_n;
  output rempty;
  wire   N1, rempty_val, n1, n2, n3, n4, n5, n6, n7, n8, n9;
  wire   [4:0] rbinnext;
  wire   [3:0] rgraynext;
  wire   [3:1] add_17_carry;

  DFFASX1_RVT rempty_reg ( .D(rempty_val), .CLK(rclk), .SETB(rrst_n), .Q(
        rempty), .QN(n1) );
  DFFARX1_RVT rbin_reg_0_ ( .D(rbinnext[0]), .CLK(rclk), .RSTB(rrst_n), .Q(
        raddr[0]) );
  DFFARX1_RVT rbin_reg_1_ ( .D(rbinnext[1]), .CLK(rclk), .RSTB(rrst_n), .Q(
        raddr[1]) );
  DFFARX1_RVT rptr_reg_0_ ( .D(rgraynext[0]), .CLK(rclk), .RSTB(rrst_n), .Q(
        rptr[0]) );
  DFFARX1_RVT rbin_reg_2_ ( .D(rbinnext[2]), .CLK(rclk), .RSTB(rrst_n), .Q(
        raddr[2]) );
  DFFARX1_RVT rptr_reg_1_ ( .D(rgraynext[1]), .CLK(rclk), .RSTB(rrst_n), .Q(
        rptr[1]) );
  DFFARX1_RVT rbin_reg_3_ ( .D(rbinnext[3]), .CLK(rclk), .RSTB(rrst_n), .Q(
        raddr[3]) );
  DFFARX1_RVT rptr_reg_2_ ( .D(rgraynext[2]), .CLK(rclk), .RSTB(rrst_n), .Q(
        rptr[2]) );
  DFFARX1_RVT rbin_reg_4_ ( .D(rbinnext[4]), .CLK(rclk), .RSTB(rrst_n), .QN(n8) );
  DFFARX1_RVT rptr_reg_4_ ( .D(rbinnext[4]), .CLK(rclk), .RSTB(rrst_n), .Q(
        rptr[4]) );
  DFFARX1_RVT rptr_reg_3_ ( .D(rgraynext[3]), .CLK(rclk), .RSTB(rrst_n), .Q(
        rptr[3]) );
  AND4X1_RVT U12 ( .A1(n2), .A2(n3), .A3(n4), .A4(n5), .Y(rempty_val) );
  AND2X1_RVT U13 ( .A1(n6), .A2(n7), .Y(n4) );
  AND2X1_RVT U14 ( .A1(rinc), .A2(n1), .Y(N1) );
  XOR2X1_RVT U3 ( .A1(rbinnext[3]), .A2(rbinnext[4]), .Y(rgraynext[3]) );
  XOR2X1_RVT U4 ( .A1(rbinnext[2]), .A2(rbinnext[3]), .Y(rgraynext[2]) );
  XOR2X1_RVT U5 ( .A1(rbinnext[1]), .A2(rbinnext[2]), .Y(rgraynext[1]) );
  XOR2X1_RVT U6 ( .A1(rbinnext[1]), .A2(rbinnext[0]), .Y(rgraynext[0]) );
  XOR2X1_RVT U7 ( .A1(n8), .A2(n9), .Y(rbinnext[4]) );
  NAND2X0_RVT U8 ( .A1(add_17_carry[3]), .A2(raddr[3]), .Y(n9) );
  XNOR2X1_RVT U9 ( .A1(rgraynext[1]), .A2(rq2_wptr[1]), .Y(n5) );
  XNOR2X1_RVT U10 ( .A1(rgraynext[2]), .A2(rq2_wptr[2]), .Y(n3) );
  XNOR2X1_RVT U11 ( .A1(rgraynext[3]), .A2(rq2_wptr[3]), .Y(n2) );
  XNOR2X1_RVT U15 ( .A1(rbinnext[4]), .A2(rq2_wptr[4]), .Y(n7) );
  XOR2X1_RVT U16 ( .A1(raddr[3]), .A2(add_17_carry[3]), .Y(rbinnext[3]) );
  XOR2X1_RVT U17 ( .A1(raddr[2]), .A2(add_17_carry[2]), .Y(rbinnext[2]) );
  XOR2X1_RVT U18 ( .A1(raddr[1]), .A2(add_17_carry[1]), .Y(rbinnext[1]) );
  XNOR2X1_RVT U19 ( .A1(rgraynext[0]), .A2(rq2_wptr[0]), .Y(n6) );
  XOR2X1_RVT U20 ( .A1(raddr[0]), .A2(N1), .Y(rbinnext[0]) );
  AND2X1_RVT U21 ( .A1(N1), .A2(raddr[0]), .Y(add_17_carry[1]) );
  AND2X1_RVT U22 ( .A1(add_17_carry[1]), .A2(raddr[1]), .Y(add_17_carry[2]) );
  AND2X1_RVT U23 ( .A1(add_17_carry[2]), .A2(raddr[2]), .Y(add_17_carry[3]) );
endmodule


module wptr_full_ADDRSIZE4 ( wfull, waddr, wptr, wq2_rptr, winc, wclk, wrst_n
 );
  output [3:0] waddr;
  output [4:0] wptr;
  input [4:0] wq2_rptr;
  input winc, wclk, wrst_n;
  output wfull;
  wire   N1, wfull_val, n1, n2, n3, n4, n5, n6, n7, n8, n9;
  wire   [4:0] wbinnext;
  wire   [3:0] wgraynext;
  wire   [3:1] add_17_carry;

  DFFARX1_RVT wfull_reg ( .D(wfull_val), .CLK(wclk), .RSTB(wrst_n), .Q(wfull), 
        .QN(n1) );
  DFFARX1_RVT wbin_reg_0_ ( .D(wbinnext[0]), .CLK(wclk), .RSTB(wrst_n), .Q(
        waddr[0]) );
  DFFARX1_RVT wbin_reg_1_ ( .D(wbinnext[1]), .CLK(wclk), .RSTB(wrst_n), .Q(
        waddr[1]) );
  DFFARX1_RVT wptr_reg_0_ ( .D(wgraynext[0]), .CLK(wclk), .RSTB(wrst_n), .Q(
        wptr[0]) );
  DFFARX1_RVT wbin_reg_2_ ( .D(wbinnext[2]), .CLK(wclk), .RSTB(wrst_n), .Q(
        waddr[2]) );
  DFFARX1_RVT wptr_reg_1_ ( .D(wgraynext[1]), .CLK(wclk), .RSTB(wrst_n), .Q(
        wptr[1]) );
  DFFARX1_RVT wbin_reg_3_ ( .D(wbinnext[3]), .CLK(wclk), .RSTB(wrst_n), .Q(
        waddr[3]) );
  DFFARX1_RVT wptr_reg_2_ ( .D(wgraynext[2]), .CLK(wclk), .RSTB(wrst_n), .Q(
        wptr[2]) );
  DFFARX1_RVT wbin_reg_4_ ( .D(wbinnext[4]), .CLK(wclk), .RSTB(wrst_n), .QN(n8) );
  DFFARX1_RVT wptr_reg_4_ ( .D(wbinnext[4]), .CLK(wclk), .RSTB(wrst_n), .Q(
        wptr[4]) );
  DFFARX1_RVT wptr_reg_3_ ( .D(wgraynext[3]), .CLK(wclk), .RSTB(wrst_n), .Q(
        wptr[3]) );
  AND4X1_RVT U12 ( .A1(n2), .A2(n3), .A3(n4), .A4(n5), .Y(wfull_val) );
  AND2X1_RVT U13 ( .A1(n6), .A2(n7), .Y(n4) );
  AND2X1_RVT U14 ( .A1(winc), .A2(n1), .Y(N1) );
  XOR2X1_RVT U3 ( .A1(wbinnext[3]), .A2(wbinnext[4]), .Y(wgraynext[3]) );
  XOR2X1_RVT U4 ( .A1(wbinnext[2]), .A2(wbinnext[3]), .Y(wgraynext[2]) );
  XOR2X1_RVT U5 ( .A1(wbinnext[1]), .A2(wbinnext[2]), .Y(wgraynext[1]) );
  XOR2X1_RVT U6 ( .A1(wbinnext[1]), .A2(wbinnext[0]), .Y(wgraynext[0]) );
  XOR2X1_RVT U7 ( .A1(n8), .A2(n9), .Y(wbinnext[4]) );
  NAND2X0_RVT U8 ( .A1(add_17_carry[3]), .A2(waddr[3]), .Y(n9) );
  XNOR2X1_RVT U9 ( .A1(wgraynext[0]), .A2(wq2_rptr[0]), .Y(n5) );
  XNOR2X1_RVT U10 ( .A1(wgraynext[1]), .A2(wq2_rptr[1]), .Y(n3) );
  XNOR2X1_RVT U11 ( .A1(wgraynext[2]), .A2(wq2_rptr[2]), .Y(n2) );
  XOR2X1_RVT U15 ( .A1(wq2_rptr[4]), .A2(wbinnext[4]), .Y(n7) );
  XOR2X1_RVT U16 ( .A1(wq2_rptr[3]), .A2(wgraynext[3]), .Y(n6) );
  XOR2X1_RVT U17 ( .A1(waddr[3]), .A2(add_17_carry[3]), .Y(wbinnext[3]) );
  XOR2X1_RVT U18 ( .A1(waddr[2]), .A2(add_17_carry[2]), .Y(wbinnext[2]) );
  XOR2X1_RVT U19 ( .A1(waddr[1]), .A2(add_17_carry[1]), .Y(wbinnext[1]) );
  XOR2X1_RVT U20 ( .A1(waddr[0]), .A2(N1), .Y(wbinnext[0]) );
  AND2X1_RVT U21 ( .A1(N1), .A2(waddr[0]), .Y(add_17_carry[1]) );
  AND2X1_RVT U22 ( .A1(add_17_carry[1]), .A2(waddr[1]), .Y(add_17_carry[2]) );
  AND2X1_RVT U23 ( .A1(add_17_carry[2]), .A2(waddr[2]), .Y(add_17_carry[3]) );
endmodule


module fifo1 ( rdata, wfull, rempty, wdata, winc, wclk, wrst_n, rinc, rclk, 
        rrst_n );
  output [7:0] rdata;
  input [7:0] wdata;
  input winc, wclk, wrst_n, rinc, rclk, rrst_n;
  output wfull, rempty;

  wire   [4:0] wq2_rptr;
  wire   [4:0] rptr;
  wire   [4:0] rq2_wptr;
  wire   [4:0] wptr;
  wire   [3:0] waddr;
  wire   [3:0] raddr;

  sync_r2w sync_r2w ( .wq2_rptr(wq2_rptr), .rptr(rptr), .wclk(wclk), .wrst_n(
        wrst_n) );
  sync_w2r sync_w2r ( .rq2_wptr(rq2_wptr), .wptr(wptr), .rclk(rclk), .rrst_n(
        rrst_n) );
  fifomem_DATASIZE8_ADDRSIZE4 fifomem ( .rdata(rdata), .wdata(wdata), .waddr(
        waddr), .raddr(raddr), .wclken(winc), .wfull(wfull), .wclk(wclk) );
  rptr_empty_ADDRSIZE4 rptr_empty ( .rempty(rempty), .raddr(raddr), .rptr(rptr), .rq2_wptr(rq2_wptr), .rinc(rinc), .rclk(rclk), .rrst_n(rrst_n) );
  wptr_full_ADDRSIZE4 wptr_full ( .wfull(wfull), .waddr(waddr), .wptr(wptr), 
        .wq2_rptr(wq2_rptr), .winc(winc), .wclk(wclk), .wrst_n(wrst_n) );
endmodule

