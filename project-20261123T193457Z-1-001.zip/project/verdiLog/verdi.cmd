simSetSimulator "-vcssv" -exec "./simv" -args
debImport "-dbdir" "./simv.daidir"
debLoadSimResult /home/dicdlabc05/work/23ecb1a30_35_lpic/project/fifo1.fsdb
wvCreateWindow
verdiWindowResize -win $_Verdi_1 "510" "153" "900" "700"
verdiSetActWin -win $_nWave2
verdiWindowResize -win $_Verdi_1 "510" "153" "900" "700"
verdiSetActWin -dock widgetDock_MTB_SOURCE_TAB_1
srcHBSelect "fifo1_tb" -win $_nTrace1
verdiSetActWin -dock widgetDock_<Inst._Tree>
schCreateWindow -delim "." -win $_nSchema1 -scope "fifo1_tb"
verdiSetActWin -win $_nSchema_3
schPrint -win $_nSchema3 -paper A4 -file \
         "/home/dicdlabc05/work/23ecb1a30_35_lpic/project/print.pdf" -signLoc \
         lowerRight -design "fifo1_tb" -designer "dicdlabc05" -date \
         "Oct 13, 2026" -printRegion fitToPage
schSelect -win $_nSchema3 -inst "uut"
schPushViewIn -win $_nSchema3
schPrint -win $_nSchema3 -paper A4 -file \
         "/home/dicdlabc05/work/23ecb1a30_35_lpic/project/print1.pdf" -signLoc \
         lowerRight -design "fifo1" -designer "dicdlabc05" -date \
         "Oct 13, 2026" -printRegion fitToPage
schSelect -win $_nSchema3 -inst "sync_w2r"
schPushViewIn -win $_nSchema3
verdiDockWidgetSetCurTab -dock widgetDock_MTB_SOURCE_TAB_1
verdiSetActWin -dock widgetDock_MTB_SOURCE_TAB_1
srcHBSelect "fifo1_tb" -win $_nTrace1
srcHBSelect "fifo1_tb" -win $_nTrace1
verdiSetActWin -dock widgetDock_<Inst._Tree>
srcHBSelect "fifo1_tb.uut" -win $_nTrace1
srcHBSelect "fifo1_tb.uut" -win $_nTrace1
wvCreateWindow
wvSetPosition -win $_nWave4 {("G1" 0)}
wvOpenFile -win $_nWave4 \
           {/home/dicdlabc05/work/23ecb1a30_35_lpic/project/fifo1.fsdb}
srcHBAddObjectToWave -clipboard
wvDrop -win $_nWave4
verdiSetActWin -win $_nWave4
wvZoomAll -win $_nWave4
wvZoomIn -win $_nWave4
wvZoomIn -win $_nWave4
wvSetCursor -win $_nWave4 85.432828 -snap {("uut" 6)}
wvZoomAll -win $_nWave4
wvSetPosition -win $_nWave4 {("uut" 5)}
wvSetPosition -win $_nWave4 {("uut" 10)}
wvSelectSignal -win $_nWave4 {( "uut" 1 2 3 4 5 6 7 8 9 10 )} 
wvScrollDown -win $_nWave4 0
wvPrint -win $_nWave4 -value off -legend off -inclinewidth off -stretchsignal off \
        -bypaperlayout off -start 0.000000 -end 181.194000 -slice 181.194000 \
        -printallpages on -paper A4 -color -file \
        "/home/dicdlabc05/work/23ecb1a30_35_lpic/project/print2.pdf"
debExit
