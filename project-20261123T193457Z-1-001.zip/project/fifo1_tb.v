module fifo1_tb;
    parameter DSIZE = 8;
    parameter ASIZE = 4;

    wire [DSIZE-1:0] rdata;
    wire wfull, rempty;
    reg [DSIZE-1:0] wdata;
    reg winc, wclk, wrst_n;
    reg rinc, rclk, rrst_n;

    fifo1 #(DSIZE, ASIZE) uut (
        .rdata(rdata), .wfull(wfull), .rempty(rempty),
        .wdata(wdata), .winc(winc), .wclk(wclk), .wrst_n(wrst_n),
        .rinc(rinc), .rclk(rclk), .rrst_n(rrst_n)
    );

    // Clock generation: 10ns Write Clock, 15ns Read Clock
    initial begin wclk = 0; forever #5 wclk = ~wclk; end
    initial begin rclk = 0; forever #7.5 rclk = ~rclk; end

    // Standard VCD dump for VCS
    initial begin
        $dumpfile("fifo1.vcd");
        $dumpvars(0, fifo1_tb);
    end

    // Test sequence
    initial begin
        wrst_n = 0; rrst_n = 0; winc = 0; rinc = 0; wdata = 0;
        #20 wrst_n = 1; rrst_n = 1;
        #10 wdata = 8'hAA; winc = 1;
        #10 wdata = 8'hBB;
        #10 winc = 0;
        #30 rinc = 1;
        #20 rinc = 0;
        #100 $finish;
    end
endmodule
